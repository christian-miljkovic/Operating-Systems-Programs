Christian Miljkovic
Operating Systems Bankers Lab

RUN (Assuming python3 is installed and numpy)
In terminal, navigate to the directory that contains bankers.py and the input files. Once you are in the correct directory, run the command below where “inputfile.txt” is the desired input file 
(ensure that the input file is within the same directory as the source code) to run the source code:
python3 bankers.py input1.txt

EXAMPLE

RUN
python3 bankers.py input1.txt
